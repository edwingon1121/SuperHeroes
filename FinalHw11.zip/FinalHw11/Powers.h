//  Edwin Gonzalez
//  ITP 165, Spring 2016
//  Homework 11
//  edwingon@usc.edu
//
//  Powers.h
//  FinalHw11
//
//  Created by Edwin Gonzalez on 4/28/16.
//  Copyright © 2016 Edwin Gonzalez. All rights reserved.
//

//Powers.h
#pragma once

#include <string>

//Define our 6 constant power values
const int POWER_STRENGTH = 0;
const int POWER_FLIGHT = 1;
const int POWER_LASER = 2;
const int POWER_INTEL = 3;
const int POWER_GADGETS = 4;
const int POWER_NATIONALISM = 5;

class Power {
public:
    // Returns the description of the power
    std::string getDescription();
    // Returns the ID number of the power
    virtual int getID() = 0;
    // Outputs text when using the power
    virtual void use() = 0;
    // Fights another power
    // -1 = other power wins
    // 0 = tie
    // 1 = this power wins
    virtual int fight(Power* otherPower) = 0;
protected:
    std::string mDescription;
};

class FlightPower: public Power //Flight Power class
{
public:
    int getID();
    void use();
    int fight(Power* otherPower);
    FlightPower();
};

class LaserPower: public Power //Laser Power Class
{
public:
    int getID();
    void use();
    int fight(Power* otherPower);
    LaserPower();
};

class IntelligencePower: public Power //Intelligence Power Class
{
public:
    int getID();
    void use();
    int fight(Power* otherPower);
    IntelligencePower();
};

class StrengthPower: public Power //Strength Power Class
{
public:
    int getID();
    void use();
    int fight(Power* otherPower);
    StrengthPower();
};

class NationalPower: public Power //Nationalism Power Class
{
public:
    int getID();
    void use();
    int fight(Power* otherPower);
    NationalPower();
};

class GadgetsPower: public Power //Gadgets Power Class
{
public:
    int getID();
    void use();
    int fight(Power* otherPower);
    GadgetsPower();
};

Power* powerFactory(std::string input); //Power Factory Class


