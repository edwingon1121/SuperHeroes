//  Edwin Gonzalez
//  ITP 165, Spring 2016
//  Homework 11
//  edwingon@usc.edu
//
//  Hero.cpp
//  FinalHw11
//
//  Created by Edwin Gonzalez on 4/28/16.
//  Copyright © 2016 Edwin Gonzalez. All rights reserved.
//


#include "Hero.h"
#include <iostream>
#include <cstdlib>

Hero::Hero( std::string& name, int health, std::vector<Power*> &powers)
{
    mName = name;
    mMaxHealth = health;
    mHealth = mMaxHealth;
    mPowers=powers;
    
}

std::string Hero::getName()
{
    return mName;
}

void Hero::printPowers()
{
    std::cout << getName() << " has the following powers..." << std::endl;
    
    std::cout<<mPowers.size()<<std::endl;
    
    for (int i = 0; i < mPowers.size(); i++)
    {
        std::cout << mPowers[i]->getDescription() << std::endl;
    }
}

// Function: getHealth
// Purpose: Get health value for a hero
// Parameters: None.
// Returns: mHealth
int Hero::getHealth()
{
    return mHealth;
}

// Function: takedamage
// Purpose: Reduce the Hero's Health by 1
// Parameters: None.
// Returns: mHealth--
void Hero::takeDamage()
{
    mHealth--;
}

// Function: resetHealth
// Purpose: Resets the health of a Heroes
// Parameters: None.
// Returns: mMaxHealth
void Hero::resetHealth()
{
    mHealth = mMaxHealth;
}

// Function: printHealth
// Purpose: Prints out the Hero's name and health value
// Parameters: None.
// Returns: Nothing
void Hero::printHealth()
{
    std::cout << getName() << " has " << getHealth() << " health " << std::endl;
}

// Function: useRandomPower
// Purpose: Randomized the power the hero uses
// Parameters: None.
// Returns: A random power

Power* Hero::useRandomPower()
{
    int ranNum=std::rand()% mPowers.size();
    return mPowers[ranNum];
}
