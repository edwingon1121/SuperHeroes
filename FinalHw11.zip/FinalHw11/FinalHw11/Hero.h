//  Edwin Gonzalez
//  ITP 165, Spring 2016
//  Homework 11
//  edwingon@usc.edu
//
//  Hero.h
//  FinalHw11
//
//  Created by Edwin Gonzalez on 4/28/16.
//  Copyright © 2016 Edwin Gonzalez. All rights reserved.
//

//Hero.h
#pragma once
#include "Powers.h"
#include <vector>

class Hero
{
public:
    // Constructs a hero based on the definition
    Hero(std::string& name, int health, std::vector<Power*> &powers);
    
    std::string getName(); // Returns the name of the hero
    
    void printPowers(); // Prints out all of the powers
    
    int getHealth(); // Returns the current health of the hero
    
    void takeDamage(); // Causes the hero to take one point of damage
    
    void resetHealth(); // Resets the heroes' health to the max value
    
    void printHealth(); // Prints health status
    
    Power* useRandomPower(); //Returns a power pointer.
    
    
private:
    // Max health
    int mMaxHealth;
    
    // Current health
    int mHealth;
    
    // Name of hero
    std::string mName;
    
    // Vector of pointers to powers
    std::vector<Power*> mPowers;
    
};
