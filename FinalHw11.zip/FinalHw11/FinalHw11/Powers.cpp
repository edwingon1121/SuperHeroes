//  Edwin Gonzalez
//  ITP 165, Spring 2016
//  Homework 11
//  edwingon@usc.edu
//
//  Powers.cpp
//  FinalHw11
//
//  Created by Edwin Gonzalez on 4/28/16.
//  Copyright © 2016 Edwin Gonzalez. All rights reserved.
//

#include "Powers.h"
#include <iostream>


std::string Power::getDescription() //returns a description
{
    return mDescription;
}

int FlightPower::getID() 
{
    return POWER_FLIGHT;
}

void FlightPower::use()
{
    std::cout<<" flies to a place super far away"<<std::endl;
}

FlightPower::FlightPower()
{
    mDescription= "Now you are able to fly!";
}

int FlightPower::fight(Power* otherPower) //When using flight in a fight
{
    int retVal=0;
    switch (otherPower->getID())
    {
        case POWER_STRENGTH:
        {
            retVal=1;
            std::cout<< "Flight Won and was able to dodge the attack."<<std::endl;
            break;
        }
        case POWER_FLIGHT:
        {
            retVal=0;
            std::cout<<"It is a tie! Both superheroes flew away!"<<std::endl;
            break;
        }
        case POWER_INTEL:
        {
            retVal=1;
            std::cout<<"Haha I beat your smarts! Flight won!"<<std::endl;
            break;
        }
        case POWER_GADGETS:
        {
            retVal=-1;
            std::cout<<"Gadgets rule! Flight loses."<<std::endl;
            break;
        }
        case POWER_LASER:
        {
            retVal=-1;
            std::cout<<"Flight loses! Pew Pew Pew!!"<<std::endl;
            break;
        }
        case POWER_NATIONALISM:
        {
            retVal=1;
            std::cout<<"Flight wins. Gotcha Nationalism always loses!"<<std::endl;
            break;
        }
            
    }
    
    
    return retVal;
}
int GadgetsPower::getID()
{
    return POWER_GADGETS;
}
void GadgetsPower::use()
{
    std::cout<<" Gadgets are ready to use!"<<std::endl;
}
GadgetsPower::GadgetsPower()
{
    mDescription="Gadgets allow you to use technology against your opponent!!";
}
int GadgetsPower::fight(Power* otherPower) //When using gagdets in a fight
{
    int retVal=0;
    switch (otherPower->getID())
    {
            //EDIT THESE!!!
        case POWER_FLIGHT:
        {
            retVal=-1;
            std::cout<<"Do you even lift? Strength loses!"<<std::endl;
            break;
        }
        case POWER_GADGETS:
        {
            retVal=1;
            std::cout<<"LOOK AT MY MUSCLES! Strength wins!"<<std::endl;
            break;
        }
        case POWER_INTEL:
        {
            retVal=-1;
            std::cout<<"Haha they out smarted you! Strength loses!"<<std::endl;
            break;
        }
        case POWER_LASER:
        {
            retVal=1;
            std::cout<<"I can fight you in my sleep! Strength wins!!"<<std::endl;
            break;
        }
        case POWER_NATIONALISM:
        {
            retVal=1;
            std::cout<<"Strength wins. Gotcha Nationalism always loses!"<<std::endl;
            break;
        }
        case POWER_STRENGTH:
        {
            retVal=0;
            std::cout<< "You are equal in strength. They TIE!"<<std::endl;
            break;
        }
            
    }
    
    return retVal;
}

int IntelligencePower::getID()
{
    return POWER_INTEL;
}

void IntelligencePower::use()
{
    std::cout<<" His brain is about to explode!"<<std::endl;
}

IntelligencePower::IntelligencePower()
{
    mDescription="Now there IQ is over 90000!!";
}

int IntelligencePower::fight(Power* otherPower) //When fighting using Intelligence
{
    int retVal=0;
    switch (otherPower->getID())
    {
        case POWER_FLIGHT:
        {
            retVal=-1;
            std::cout<<"The opponent flew away. Intelligence loses!"<<std::endl;
            break;
        }
        case POWER_GADGETS:
        {
            retVal=1;
            std::cout<<"Looks like he rewired the gadgets and blew up! Intelligence wins!"<<std::endl;
            break;
        }
        case POWER_INTEL:
        {
            retVal=0;
            std::cout<<"Both of their mindpowers are equal! IT'S a TIE!"<<std::endl;
            break;
        }
        case POWER_LASER:
        {
            retVal=-1;
            std::cout<<"He blew his brains out! Intelligence loses!!"<<std::endl;
            break;
        }
        case POWER_NATIONALISM:
        {
            retVal=1;
            std::cout<<"Intelligence wins. Gotcha Nationalism always loses!"<<std::endl;
            break;
        }
        case POWER_STRENGTH:
        {
            retVal=0;
            std::cout<< "The pen is mighter than the sword. Intelligence wins!"<<std::endl;
            break;
        }
    }
    
    return retVal;
    
}

int LaserPower::getID()
{
    return POWER_LASER;
}

void LaserPower::use()
{
    std::cout<<" Lasers are all fired up!"<<std::endl;
}

LaserPower::LaserPower()
{
    mDescription="Pew Pew! Lasers on!";
}

int LaserPower::fight(Power* otherPower) //When fighting with lasers
{
    int retVal=0;
    switch (otherPower->getID())
    {
        case POWER_FLIGHT:
        {
            retVal=1;
            std::cout<<"Team Rocket is blasting off again! Laser WINS!"<<std::endl;
            break;
        }
        case POWER_GADGETS:
        {
            retVal=-1;
            std::cout<<"He has gadgets that reflects Lasers. Laser LOSE!"<<std::endl;
            break;
        }
        case POWER_INTEL:
        {
            retVal=1;
            std::cout<<"My lasers are smarter than you! Lasers WIN!"<<std::endl;
            break;
        }
        case POWER_LASER:
        {
            retVal=0;
            std::cout<<"Lasers against lasers. IT'S a TIE!"<<std::endl;
            break;
        }
        case POWER_NATIONALISM:
        {
            retVal=1;
            std::cout<<"LASERS WIN! Gotcha Nationalism always loses!"<<std::endl;
            break;
        }
        case POWER_STRENGTH:
        {
            retVal=-1;
            std::cout<< "Lasers are not effective. Lasers lose!"<<std::endl;
            break;
        }
    }
    return retVal;
    
}
int NationalPower::getID()
{
    return POWER_NATIONALISM;
}

void NationalPower::use()
{
    std::cout<<" America Heck Yeah!!"<<std::endl;
}

NationalPower::NationalPower()
{
    mDescription="The nation has come together.";
}

int NationalPower::fight(Power* otherPower) //When fighting against nationalism
{
    int retVal=0;
    switch (otherPower->getID())
    {
        case POWER_FLIGHT:
        {
            retVal=-1;
            std::cout<<"Nationalism always loses!"<<std::endl;
            break;
        }
        case POWER_GADGETS:
        {
            retVal=-1;
            std::cout<<"Gadgets were too quick! Nationalism Loses!!."<<std::endl;
            break;
        }
        case POWER_INTEL:
        {
            retVal=-1;
            std::cout<<"Haha they out smarted you! Nationalism loses!"<<std::endl;
            break;
        }
        case POWER_LASER:
        {
            retVal=-1;
            std::cout<<"Burnt to a toast! Nationalism loses!!"<<std::endl;
            break;
        }
        case POWER_NATIONALISM:
        {
            retVal=0;
            std::cout<<"They have TIED!"<<std::endl;
            break;
        }
        case POWER_STRENGTH:
        {
            retVal=-1;
            std::cout<< "This isn't even a fight. Nationalism loses!"<<std::endl;
            break;
        }
    }
    
    return retVal;
}

int StrengthPower::getID()
{
    return POWER_STRENGTH;
}

void StrengthPower::use()
{
    std::cout<<" Flex your muscles!"<<std::endl;
}

StrengthPower::StrengthPower()
{
    mDescription="Now you are super buff!";
}

int StrengthPower::fight(Power* otherPower) //When fighting with strength
{
    int retVal=0;
    switch (otherPower->getID())
    {
        case POWER_FLIGHT:
        {
            retVal=-1;
            std::cout<<"Do you even lift? Strength loses!"<<std::endl;
            break;
        }
        case POWER_GADGETS:
        {
            retVal=1;
            std::cout<<"LOOK AT MY MUSCLES! Strength wins!"<<std::endl;
            break;
        }
        case POWER_INTEL:
        {
            retVal=-1;
            std::cout<<"Haha they out smarted you! Strength loses!"<<std::endl;
            break;
        }
        case POWER_LASER:
        {
            retVal=1;
            std::cout<<"I can fight you in my sleep! Strength wins!!"<<std::endl;
            break;
        }
        case POWER_NATIONALISM:
        {
            retVal=1;
            std::cout<<"Strength wins. Gotcha Nationalism always loses!"<<std::endl;
            break;
        }
        case POWER_STRENGTH:
        {
            retVal=0;
            std::cout<< "You are equal in strength. They TIE!"<<std::endl;
            break;
        }
    }
    
    return retVal;
}


Power* powerFactory (std::string input) // Checks the powers and creates a new power.
{
    Power* retVal=nullptr;
    
    if (input=="flight")
    {
        retVal=new FlightPower();
    }
    else if (input=="gadgets")
    {
        retVal=new GadgetsPower();
    }
    else if (input=="laser")
    {
        retVal=new LaserPower();
    }
    else if (input=="nationalism")
    {
        retVal= new NationalPower();
    }
    else if (input=="strength")
    {
        retVal= new StrengthPower();
    }
    else if (input=="intelligence")
    {
        retVal= new IntelligencePower();
    }
    return retVal;
}



