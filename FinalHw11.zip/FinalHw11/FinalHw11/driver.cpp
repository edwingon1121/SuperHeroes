//  Edwin Gonzalez
//  ITP 165, Spring 2016
//  Homework 11
//  edwingon@usc.edu
//
//  driver.cpp
//  FinalHw11
//
//  Created by Edwin Gonzalez on 4/28/16.
//  Copyright © 2016 Edwin Gonzalez. All rights reserved.
//

#include "Hero.h"
#include "Powers.h"
#include <fstream>
#include <sstream>
#include <iostream>

// Function:loadHero
// Purpose: To read in the info from txt files
// Parameters: A string containing the file's name and hero pointers
// Returns: Nothing
void loadHero(std::string fileName, std::vector<Hero*> &heroVector)
{
    // Open the file
    std::ifstream file(fileName);
    
    if (file.is_open())
    {
        //Read the Hero name
        std::string name;
        file>>name;
        
        //Read hero max health
        int health;
        file>>health;
        
        int powerNum=0;
        
        //Read the number of powers
        std::stringstream powersLine;
        std::string ss;
        file.ignore();
        std::getline(file, ss);
        
        powersLine<<ss;
        
        powersLine>>powerNum;
        
        std::string aPower;
        //Read the power names
        std::vector<Power*> powers;
        
        for ( int i=0; i<powerNum; i++ ) {
            
            powersLine>>aPower;
            
            Power* var=powerFactory(aPower);
            powers.push_back(var);
        }
        
        Hero *hero = new Hero(name, health, powers);
        heroVector.push_back(hero);
        
        file.close();
    }
        else
        {
          std::cout << "File not found!" << std::endl;
        }
}

// Function: printRoster
// Purpose: Shows all the Heroes that have been loaded
// Parameters: A vector of Hero pointers
// Returns: Nothing.
void printRoster(std::vector<Hero*>& heroVector)
{
    if (heroVector.size() > 0)
    {
        std::cout << "The following " << heroVector.size() << " heroes are loaded..." << std::endl;
        std::cout << "---------------------------------------" << std::endl;
        
        for (unsigned int i = 0; i < heroVector.size(); i++)
        {
            heroVector[i]->printPowers();
            std::cout << "---------------------------------------" << std::endl;
        }
    }
}

// Function: selectHero
// Purpose: Shows Heroes that are avaliable to use
// Parameters: Hero pointers within a vector
// Returns: The hero of your choice.
Hero* selectHero(std::vector<Hero*> &hero)
{
    for (int i=0; i<hero.size(); i++)
    {
        std::cout<< i<<". " << hero[i]->getName()<<std::endl;
    }
    
    int choice=0;
    std::cin>>choice;
    
    return hero[choice];
}

// Function: selectCombat
// Purpose: Allows two Heroes to fight
// Parameters: a vector of hero pointers
// Returns: Nothing.
void selectCombat(std::vector <Hero*> combatHero)
{
    std::cout<<"Select a hero: ";
    Hero* hero1=selectHero(combatHero);
    std::cout<<"Select another hero: ";
    Hero* hero2=selectHero(combatHero);

    while (true)
    {
        std::cout << "---------------------------------------" << std::endl;
        hero1->printHealth();
        hero2->printHealth();
        
        Power* power1= hero1->useRandomPower();
        Power* power2= hero2->useRandomPower();
        std::cout<<hero1->getName();
        power1->use();
        
        std::cout<<hero2->getName();
        power2->use();
        
        int result= power1->fight(power2);
        if (result==1)
        {
            hero2->takeDamage();
        }
        else if (result==-1)
        {
            hero1->takeDamage();
        }
        
        if (hero1->getHealth()>0 && hero2->getHealth()==0)
        {
            std::cout<< hero1->getName() <<" WINS!!"<<std::endl;
            std::cout << "---------------------------------------" << std::endl;
            break;
        }
        else if (hero1->getHealth()==0 && hero2->getHealth()>0)
        {
            std::cout<< hero2->getName()<<" WINS!!!"<<std::endl;
            std::cout << "---------------------------------------" << std::endl;
            break;
        }
    }
}
int main()
{
    // Seed random numbers
    srand(time(nullptr));
    
    //Vector of Hero pointers
    std::vector<Hero*> heroVector;
    
    bool quit = false;
    
    while (!quit)
    {
        std::cout << "Choose an option:" << std::endl;
        std::cout << "1. Load a Hero" << std::endl;
        std::cout << "2. Print Hero Roster" << std::endl;
        std::cout << "3. Hero Fight!"<<std::endl;
        std::cout << "4. Quit" << std::endl;
        std::cout << "> ";
        
        int option=0;
        std::cin>>option;
        
        if (option == 1)
        {
            std::string filename;
            std::cout << "Enter the file to load: ";
            std::cin>>filename;
            loadHero( filename, heroVector);
        }
        else if (option == 2)
        {
            if (heroVector.size() == 0)
            {
                std::cout << "You need to load heroes first!" << std::endl;
            }
            else
            {
                printRoster(heroVector);
            }
        }
        else if (option==3)
        {
            if (heroVector.size()==0)
            {
                std::cout<<"Need to load a hero" <<std::endl;
            }
            else
            {
                selectCombat(heroVector);
            }
        }
        else if (option == 4)
        {
            quit = true;
            std::cout<<"Quitting......."<<std::endl;
        }
        else
        {
            std::cout << "Invalid option!" << std::endl;
        }
    }
}
