//
//  main.cpp
//  FinalHw11
//
//  Created by Edwin Gonzalez on 4/28/16.
//  Copyright © 2016 Edwin Gonzalez. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
